package com.diagonistic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.diagonistic.service.AdminService;

@Controller
public class AdminController {

	@Autowired
	private AdminService adService;
	
	@RequestMapping(value="/diagonisticService", method=RequestMethod.GET)
	public String showHomePage() {
		return "home";
	}
	
	@RequestMapping(value="/adminLoginPage", method=RequestMethod.GET)
	public String showAdminLoginPage() {
		return "adminlogin";
	}
	
	@RequestMapping(value="/adminHome", method=RequestMethod.POST)
	public String showAdminHome(ModelMap model,@RequestParam String name, @RequestParam String password) {
		boolean isValid = adService.validateUserIdPassword(name, password);
		if(isValid) {
			model.put("name", name);
			return "adminhome";
		}else {
			model.put("message", "Invalid Credentials");
			return "adminlogin";
		}	
	}

//	
//	@RequestMapping(value="/patientLoginPage", method=RequestMethod.GET)
//	public String showPatientLoginPage() {
//		return "patientlogin";
//	}
//	
//	@RequestMapping(value="/patientHome", method=RequestMethod.POST)
//	public String showPatientHome(ModelMap model,@RequestParam String name, @RequestParam String password) {
//		boolean isValid = adService.validateUserIdPassword(name, password);
//		if(isValid) {
//			model.put("name", name);
//			return "patienthome";
//		}else {
//			model.put("message", "Invalid Credentials");
//			return "patientlogin";
//		}	
//	}
	
}
