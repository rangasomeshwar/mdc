package com.diagonistic.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.diagonistic.entities.Doctor;

import com.diagonistic.repositry.*;

import com.diagonistic.service.AdminService;

@Controller
public class DoctorController {

	@Autowired
	private AdminService adService;
	@Autowired
	private DoctorRepositry docRep;

	@RequestMapping(value = "/doctorLoginPage", method = RequestMethod.GET)
	public String showDoctorLoginPage() {
		return "doctorlogin";
	}

	/*@RequestMapping(value = "/doctorHome", method = RequestMethod.POST)
	public String showDoctorHome(ModelMap model, @RequestParam String name, @RequestParam String password) {
		boolean isValid = adService.validateUserIdPassword(name, password);
		if (isValid) {
			model.put("name", name);
			return "doctorhome";
		} else {
			model.put("message", "Invalid Credentials");
			return "doctorlogin";
		}
	}*/
	@GetMapping("/doctorReg")
	public String showRegistrationPage(@ModelAttribute("doctor") Doctor doctor){
		return "doctorregistrationpage";
	}
	
	@PostMapping("/doctorRegistration")
	public String fillRegPage(@ModelAttribute("doctor") Doctor doctor,BindingResult result,ModelMap model){
		if(result.hasErrors()){
			return "doctorregistrationpage";
		}
		else{
			Integer id=doctor.getDoctorId();
			model.addAttribute("Doctor",new Doctor());
			model.addAttribute("id",id);
			
			docRep.save(doctor);
			return "doctorhome";
		}
		
	}
    @PostMapping("/doctorHome")
	public String showDoctorHome(ModelMap model,@RequestParam(value="emailId") String emailId,@RequestParam(value="password")  String password) {
			
		model.addAttribute("emailId",emailId);	
		Doctor doctor=docRep.findByEmailId(emailId);
		if(doctor.getPassword().equals(password)){
		   return "doctorhomepage";
		}
		else{
			String msg="Invalid Credentails";
			model.addAttribute("msg",msg);
			return "doctorlogin";
		}
	}
	
}
