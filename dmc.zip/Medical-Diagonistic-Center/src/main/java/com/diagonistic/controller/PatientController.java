package com.diagonistic.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import com.diagonistic.entities.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.diagonistic.service.AdminService;
import com.diagonistic.repositry.*;
import org.springframework.validation.BindingResult;

@Controller
public class PatientController {

	@Autowired
	private AdminService adService;
	@Autowired
	private PatRespositry patRep;
	
//	@RequestMapping(value="/diagonisticService", method=RequestMethod.GET)
//	public String showHomePage() {
//		return "home";
//	}
	
	@RequestMapping(value="/patientLoginPage", method=RequestMethod.GET)
	public String showPatientLoginPage() {
		return "patientlogin";
	}
	
	/*@RequestMapping(value="/patientHome", method=RequestMethod.POST)
	public String showPatientHome(ModelMap model,@RequestParam String name, @RequestParam String password) {
		boolean isValid = adService.validateUserIdPassword(name, password);
		if(isValid) {
			model.put("name", name);
			return "patienthome";
		}else {
			model.put("message", "Invalid Credentials");
			return "patientlogin";
		}	
	}*/
	@GetMapping("/patientReg")
	public String showRegistrationPage(@ModelAttribute("patient") Patient patient){
		return "patientregistration";
	}
	@PostMapping("/patientRegistration1") 
	public String viewPatientHomePage(@Valid @ModelAttribute("patient") Patient patient,BindingResult result,ModelMap model){
		if(result.hasErrors()){
			return"patientregistration";
		}
		else{
		String msg="patient you are successfully registered and your id is";
		Integer id=patient.getPatientId();
		
		model.addAttribute("Patient", new Patient());
		model.addAttribute("msg",msg);
		model.addAttribute("id",id);
		patRep.save(patient);
		return "patienthome";
		}
		
	}
	@PostMapping("/patientHome")
	public String showPatientHome(ModelMap model,@RequestParam(value="emailId") String emailId,@RequestParam(value="password")  String password) {
			
		model.addAttribute("emailId",emailId);	
		Patient patient=patRep.findByEmailId(emailId);
		if(patient.getPassword().equals(password)){
		   return "patienthomepage";
		}
		else{
			String msg="Invalid Credentails";
			model.addAttribute("msg",msg);
			return "patientlogin";
		}
	}
	/*@ModelAttribute("dgServicesList")
	public Map<String,String>services(){
		Map<String,String>dgServicesList=new HashMap<String,String>();
		
		dgServicesList.put("Clinical diagnosis", "Clinical diagnosis");
		dgServicesList.put("Tissue diagnosis", "Tissue diagnosis");
		dgServicesList.put("Tissue diagnosis", "Tissue diagnosis");
		dgServicesList.put("Tissue diagnosis", "Tissue diagnosis");
		dgServicesList.put("Tissue diagnosis", "Tissue diagnosis");
		dgServicesList.put("Tissue diagnosis", "Tissue diagnosis");
		dgServicesList.put("Tissue diagnosis", "Tissue diagnosis");
		dgServicesList.put("Tissue diagnosis", "Tissue diagnosis");
		dgServicesList.put("Tissue diagnosis", "Tissue diagnosis");
		dgServicesList.put("Tissue diagnosis", "Tissue diagnosis");
		dgServicesList.put("Tissue diagnosis", "Tissue diagnosis");
		return dgServicesList;
	}
	*/
}
