package com.diagonistic.service;

import org.springframework.stereotype.Component;

@Component
public class AdminService {
	
	public boolean validateUserIdPassword(String name, String password) {
		if(name.equals("Narender") && password.equals("12345")){
			return true;
		}
		return false;
	}
	
}
