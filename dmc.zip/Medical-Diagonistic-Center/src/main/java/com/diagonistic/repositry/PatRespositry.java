package com.diagonistic.repositry;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.diagonistic.entities.Patient;
public interface PatRespositry extends JpaRepository<Patient, Integer>{

	Patient findByEmailId(String emailId);
    //@Query(value="SELECT p  FROM Patient p WHERE p.emailId=?1",nativeQuery = true)
	
    
    
}
