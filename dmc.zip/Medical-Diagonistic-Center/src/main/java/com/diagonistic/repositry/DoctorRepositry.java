package com.diagonistic.repositry;

import org.springframework.data.jpa.repository.JpaRepository;
import com.diagonistic.entities.Doctor;

public interface DoctorRepositry extends JpaRepository<Doctor, Integer> {

	Doctor findByEmailId(String emailId);

}
