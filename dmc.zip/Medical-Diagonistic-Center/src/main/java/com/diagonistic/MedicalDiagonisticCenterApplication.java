package com.diagonistic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.*")
public class MedicalDiagonisticCenterApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalDiagonisticCenterApplication.class, args);
		System.out.println("sprint");
	}

}
